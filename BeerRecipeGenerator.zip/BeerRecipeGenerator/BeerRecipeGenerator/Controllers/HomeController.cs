﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BeerRecipeGenerator.Models;

namespace BeerRecipeGenerator.Controllers
{
    public class HomeController : Controller
    {
        //This is used for my main view
        //This will control all interactions with this program from the user and code.

        private BeerIngredientContext db;
        private BeerRecipeContext br;

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GO()
        {
            return View();
        }

        //This is suppose to be used to search through the BeerIngredients database and then select only the values that match the SearchTB
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GO(string searchString)
        {
            var beerIng = from b in db.BeerIngredients
                          select b;
            if (!String.IsNullOrEmpty(searchString))
            {
                beerIng = beerIng.Where(s => s.Ingredient.Contains(searchString));
            }

            return View(db.BeerIngredients);
        }

        public ActionResult ADD()
        {
            return View();
        }

        //This is suppose to be where Ingredients are added to the Current Recipe and Beer Recipe Database.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ADD(BeerRecipe NewIngredient)
        {
            if (ModelState.IsValid)
            {
                br.BeerRecipe.Add(NewIngredient);
                br.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(br.BeerRecipe);
        }
    }
}
