﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BeerRecipeGenerator.Models;

namespace BeerRecipeGenerator.Controllers
{
    //This class allows you to interact with the Beer Recipe Database.
    //This class creates five views that can be used to manipulate the database.
    public class BeerRecpiesController : Controller
    {
        private BeerRecipeContext db = new BeerRecipeContext();

        //
        // GET: /BeerRecpies/

        public ActionResult Index()
        {
            return View(db.BeerRecipe.ToList());
        }

        //
        // GET: /BeerRecpies/Details/5

        public ActionResult Details(int id = 0)
        {
            BeerRecipe beerrecipe = db.BeerRecipe.Find(id);
            if (beerrecipe == null)
            {
                return HttpNotFound();
            }
            return View(beerrecipe);
        }

        //
        // GET: /BeerRecpies/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /BeerRecpies/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(BeerRecipe beerrecipe)
        {
            if (ModelState.IsValid)
            {
                db.BeerRecipe.Add(beerrecipe);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(beerrecipe);
        }

        //
        // GET: /BeerRecpies/Edit/5

        public ActionResult Edit(int id = 0)
        {
            BeerRecipe beerrecipe = db.BeerRecipe.Find(id);
            if (beerrecipe == null)
            {
                return HttpNotFound();
            }
            return View(beerrecipe);
        }

        //
        // POST: /BeerRecpies/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(BeerRecipe beerrecipe)
        {
            if (ModelState.IsValid)
            {
                db.Entry(beerrecipe).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(beerrecipe);
        }

        //
        // GET: /BeerRecpies/Delete/5

        public ActionResult Delete(int id = 0)
        {
            BeerRecipe beerrecipe = db.BeerRecipe.Find(id);
            if (beerrecipe == null)
            {
                return HttpNotFound();
            }
            return View(beerrecipe);
        }

        //
        // POST: /BeerRecpies/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BeerRecipe beerrecipe = db.BeerRecipe.Find(id);
            db.BeerRecipe.Remove(beerrecipe);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}