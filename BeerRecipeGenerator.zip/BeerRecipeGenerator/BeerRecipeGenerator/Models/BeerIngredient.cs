﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace BeerRecipeGenerator.Models
{
    //This is the Model for the Beer Ingredients Database. Every time data is accessed from Beer Ingredients is will use this class.
    public class BeerIngredient
    {
        public int ID { get; set; }
        public string Ingredient { get; set; }
    }
    public class BeerIngredientContext : DbContext
    {
        public DbSet<BeerIngredient> BeerIngredients { get; set; }
    }
}