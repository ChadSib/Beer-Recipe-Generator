﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace BeerRecipeGenerator.Models
{
    //Model for the BeerRecipe Database. This is used for all interactions with the Beer Recipe Database.
    public class BeerRecipe
    {
        public int ID { get; set; }
        public string RecipeName { get; set; }
        public string BrewerName { get; set; }
        public string BeerType { get; set; }
        public string Ingredients { get; set; }
        public string Quantity { get; set; }
    }
    public class BeerRecipeContext : DbContext
    {
        public DbSet<BeerRecipe> BeerRecipe { get; set; }
    }
}